require('@alipay/appx-compiler/lib/sjsEnvInit');
require('./config$');

require('../../pages/component/story-item/story-item?hash=05d2a9730dd6009bf9446182f9c985f40f8c0f43');
require('../../pages/component/story-title/story-title?hash=05d2a9730dd6009bf9446182f9c985f40f8c0f43');
require('../../pages/homes/homes?hash=32d7d2807ed4e666ef03b4b3fe8c38ecf2e34e68');
require('../../pages/index/index?hash=32d7d2807ed4e666ef03b4b3fe8c38ecf2e34e68');
require('../../pages/movies/more-movie/more-movie?hash=32d7d2807ed4e666ef03b4b3fe8c38ecf2e34e68');
require('../../pages/SettingUp/SettingUp?hash=32d7d2807ed4e666ef03b4b3fe8c38ecf2e34e68');
require('../../pages/transaction/transaction?hash=b99c7cf157ec6be5cfcea31e713635748f401d05');
require('../../pages/orderdetail/orderdetail?hash=32d7d2807ed4e666ef03b4b3fe8c38ecf2e34e68');
