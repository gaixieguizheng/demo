## 支付宝小程序-豆瓣电影项目

### 效果图
![image](https://github.com/songhaoreact/my/blob/master/screenshots/1.png)
![image](https://github.com/songhaoreact/my/blob/master/screenshots/2.png)
![image](https://github.com/songhaoreact/my/blob/master/screenshots/3.png)

### 功能说明
接口访问来自豆瓣api,目前功能有
搜索功能
下拉刷新
上拉加载
首页启动增加css3动画
### 代码说明
部分采用es6语言，组件化，模块化开发。
### 安装说明

```
git clone https://github.com/songhaoreact/my.git

cd my

可以真机运行也可以ide运行

补充说明：

screenshots文件夹不需要，只是github上的效果图。

readme也是github上面的，都不需要。

运行前删掉screenshots和readme.md文件就行。


如果demo对你有帮助的话，帮忙点个star。

```

