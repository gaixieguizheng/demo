Page({
  data: {},
  onLoad() {},
});
