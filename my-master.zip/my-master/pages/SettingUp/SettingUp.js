Page({
  data: {},
  onLoad() {},
  bindViewTap() {
    my.setStorageSync({
      key: 'LoginStatus',
      data: {
              status: 2,
            }
    });
    my.redirectTo({
      url: '../index/index',
    });
  },
  loginTap() {
    my.navigateTo({
      url: '../transaction/transaction',
    });
  },
  loginTapYYY() {
    my.showToast('暂无开通此功能！！');
  }
  
});
