// mock列表总数
const mockTotal = 600;
var storyItem;
// 获取应用实例
const app = getApp()
var MD5s = require('../../utils/md5.js')
var tool = require('../../utils/util.js')

Page({
    data: {
        scrollTop: 0,
        toViewId: 0,
        show: false, // 是否显示加载动画
        page: 1, // 当前页数
        list: [], // 页面List数据
        moneyCountTitle:0.01,
        orderCountTitle:0
    },
    onLoad() {
        this.mySchedulde();
    },
    // onNextPage() {
    //     const toViewId = 5 + this.data.toViewId;
    //     console.log('onSuspendTitleClick = ' + toViewId);
    //     this.setData({ toViewId })
    // },

    // onScrollToTop() {
    //     const scrollTop = 0;
    //     console.log('onScrollToTop = ' + this.data.scrollTop);
    //     this.setData({ scrollTop })
    // },

    getHttpDate(page = 1) {
        let nowDate = new Date();
        let paramTime = nowDate.getTime();
        let paramDate = new Date(paramTime);
        let mm = paramDate.getMonth() + 1; // getMonth() is zero-based
        let dd = paramDate.getDate();
        if (page == 1) {
            return [paramDate.getFullYear(),
            '-',
            (mm > 9 ? '' : '0') + mm,
            '-',
            (dd > 9 ? '' : '0') + dd
            ].join('');
        }
        return [paramDate.getFullYear(),
        (mm > 9 ? '' : '0') + mm,
        (dd > 9 ? '' : '0') + dd
        ].join('');
    },
     getHttpDateTime(value) {

      var theTime = parseInt(value);// 秒
      var newTime = new Date(theTime*1000); 
      var time = newTime.getFullYear() + '-' + (newTime.getMonth() + 1) + '-' + newTime.getDate() + ' ' + newTime.getHours()+ ':' + newTime.getMinutes() + ':' + newTime.getSeconds();
      // var result= newTime.format("yyyy-MM-dd hh:mm:ss");
      return time;
    },
    onStroryClick(id) {
        // const detailUrl = 'https://zlyapi.boiin.com/app/getQrPayOrderForSingle.jhtml?';
        // console.log('detailUrl = ' + detailUrl);
        // const params = encodeURIComponent(detailUrl);
        my.navigateTo({
            url: '../orderdetail/orderdetail'
        });
    },
    /**
     * 模拟请求服务端查询数据并渲染页面
     * @method mySchedulde
     * @param {int} page 分页,默认第1页
     */
    async mySchedulde(page = 1) {
        try {
            let list = this.data.list;
            // https://news-at.zhihu.com/api/4/news/before/20190907

            // let pdate = this.getHttpDate(page);
            // console.log('pDate = ' + pdate);

            let curTime = this.getHttpDate(page);
            let start_time = curTime + ' 00:00:00';
            let end_time = curTime + ' 23:59:59';

            let res = my.getStorageSync({ key: 'LoginStatus' });
            var arg = ('start_time='+curTime+'+00%3A00%3A00&end_time='+curTime+'+23%3A59%3A59&terminal_id='+res.data.usercodes+'&workmen_uid='+res.data.userids)
            var sign=this.getSign(arg,res.data.Devekey);
            console.log('signeee = ' + sign);
            my.request({
                url: 'https://zlyapi.boiin.com/app/getQrOrderList.jhtml?',
                data: {
                  sign:sign,
                  workmen_uid:res.data.userids,
                  terminal_id:res.data.usercodes,
                  start_time:start_time,
                  end_time:end_time
                },
                success: (res) => {
                    var rstObj = JSON.parse(res.data); //字符串转为对象
                    let zhihuList = rstObj.data.list;
                    list = [...list,...zhihuList];
                    console.log('list = ' + JSON.stringify(rstObj.data.count_amount)+list.length);

                    for (let i = 0; i < list.length; i++) {
                      if(list[i]["status"] == '1'){
                        list[i]["status"] = '未支付';
                      }else if(list[i]["status"] == '2'){
                        list[i]["status"] = '交易成功';
                      }else if(list[i]["status"] == '3'){
                        list[i]["status"] = '交易失败';
                      }else if(list[i]["status"] == '4'){
                        list[i]["status"] = '交易已撤销';
                      }else if(list[i]["status"] == '5'){
                        list[i]["status"] = '交易已关闭';
                      }else if(list[i]["status"] == '6'){
                        list[i]["status"] = '没有原始交易';
                      }else if(list[i]["status"] == '7'){
                        list[i]["status"] = '交易撤销中';
                      }
                      list[i]["addtime"] = this.getHttpDateTime(list[i]["addtime"]);
                    }
                    // console.log('res = ' + JSON.stringify(res));
                    // let zhihuList = res.data.stories;
                    // list = [...list,...zhihuList];
                    // let pageTitle = { type: 1, title: `日期：${pdate}`, remarksa: `我是第${page}页`, remarksb: '' };
                    // list.push(pageTitle);
                    // console.log('list = ' + JSON.stringify(list));

                    this.setData({
                        list,
                        page,
                        show: false,
                        moneyCountTitle:rstObj.data.count_amount,
                        orderCountTitle:list.length
                    });
                    // if (page === 1) {
                    //     console.log('loading next page');
                    //     this.scrollMytrip();
                    // }
                },
                fail: function(res) {
                    my.alert({ content: 'fail' });
                },
                complete: function(res) {
                    my.hideLoading();
                }
            });
        } catch (e) {
            console.log('mySchedulde执行异常:', e);
        }
    },

    // 验签
  getSign(args, key){
    args=args.split('&');
    args=args.sort();
    var requestString = '';
    for ( var i = 0; i <args.length; i++){
      var str=args[i];
      var arr=str.split('=');
      if(arr[1]!=null&&arr[1]!=""){
      requestString=requestString + arr[0] + '=' + arr[1] + '&';
      }
    }
    requestString = requestString + 'key=' + key;
    var newSign=MD5s.hexMD5(requestString).toUpperCase();
    return newSign;
  }

});