const app = getApp()
var MD5s = require('../../utils/md5.js')

Page({
  data: {
    moneycount: '',
    isDisabled: true,
    moneyNum:0.00,
    isMoneyinput: false
  },
  onShow(){
    my.ix.onKeyEventChange((r) => {
      if (r.keyCode == 131){
        const that =this;
        let res = my.getStorageSync({ key: 'LoginStatus' });
        if(that.data.moneycount>0){
          that.moneyNum = that.data.moneycount;
        }else{
          if(r.amount>0){
            that.moneyNum = r.amount;
          }else{
            my.showToast({
              content:'支付金额不能为空',
            });
            return
          }
        }
        my.ix.startApp({
          appName: 'cashier',
          bizNo: res.data.userids,
          totalAmount: that.moneyNum,
        orderDetail: [{ name: '爱客盈商品', content: '需要支付100元', fontColor: 'gray' },{ name: '爱客盈商品1', content: '需要支付999元', fontColor: 'red' }],
        success: (Rr) => {
            // my.showToast({ content: Rr.barCode });
            that.cashPaymentTrade(Rr.barCode,r.amount);
          }
        });
      }
      if(r.keyCode == 134){
        my.navigateTo({
        url: '../SettingUp/SettingUp',
        });
      } 
    });
  },
  onLoad() {
    my.hideBackHome();
  },
  onHide(){
    my.ix.offKeyEventChange();
  },
  MoneyPayTap() {
    const that =this;
    let res = my.getStorageSync({ key: 'LoginStatus' });
    my.ix.startApp({
      appName: 'cashier',
      bizNo: res.data.userids,
      totalAmount: that.data.moneycount,
      orderDetail: [{ name: '爱客盈商品', content: '爱客盈商品订单', fontColor: 'gray' },{ name: '爱客盈商品1', content: '爱客盈商品订单', fontColor: 'red' }],
      success: (r) => {
        // my.showToast({ content: r.barCode });
        that.cashPaymentTrade(r.barCode,that.data.moneycount);
      }
    });
   },

   /**
   * @name cashPaymentTrade
   * @description 发起支付
   * @param {*} tradeNo
   * @returns
   */
  cashPaymentTrade(tradeNo,amount) {
    let res = my.getStorageSync({ key: 'LoginStatus' });
    var arg=('authCode='+tradeNo+'&amount='+amount+'&uid='+res.data.userids+'&zdcode='+res.data.usercodes);
    console.log(sign);
    var sign=this.getSign(arg,res.data.Devekey);
    return new Promise((resolve, reject) => {
      my.request({
        url: 'https://zlyapi.boiin.com/app/beSweptPCPay.jhtml?',
        data: {
          authCode: tradeNo,
          sign:sign,
          amount:amount,
          uid:res.data.userids,
          zdcode:res.data.usercodes
        },
        
        success: (result) => {
          var rstObj = JSON.parse(result.data); //字符串转为对象
          if (rstObj.status==0) {
            my.showToast({ content: rstObj.info});
          } else {
            resolve(rstObj.info);
          }
        },
        fail: (err) => {
          reject({
            message: '支付异常',
            ...err
          });
        }
      });
    });
  },
    // 获取输入密码 
  moneyInput: function (e) {
    this.setData({
      moneycount: e.detail.value,
    })
    if(e.detail.value.length == 0){
     this.setData({
      isDisabled: true
     })
    }else{
      this.setData({
      isDisabled: false
     })
    }
    
  },
    // 获取input焦点事件
  // headInputview: function () {
  //   alert('tgtgtgg');
  //   this.setData({
  //     isMoneyinput: true
  //    })
    
  // },


  // 验签
  getSign(args, key){
    args=args.split('&');
    args=args.sort();
    var requestString = '';
    for ( var i = 0; i <args.length; i++){
      var str=args[i];
      var arr=str.split('=');
      if(arr[1]!=null&&arr[1]!=""){
      requestString=requestString + arr[0] + '=' + arr[1] + '&';
      }
    }
    requestString = requestString + 'key=' + key;
    var newSign=MD5s.hexMD5(requestString).toUpperCase();
    return newSign;
  }
});
