// 获取应用实例
const app = getApp()
var MD5s = require('../../utils/md5.js')

Page({
  data: {
    remind: '加载中',
    help_status: false,
    userid_focus: false,
    passwd_focus: false,
    userid: '',
    passwd: '',
    angle: 0,
    username: '',
    password: ''
  },
  onLoad() {
    var _this = this
    setTimeout(function(){
      _this.setData({
        remind: ''
      });
    }, 1000);
  },
  bindViewTap() {
    // my.navigateTo({
    //   url: '../homes/homes',
      
    // });
//   my.ix.startApp({
//   appName: 'cashier',
//   bizNo: '12345678',
//   totalAmount: '0.01',
//   orderDetail: [{ name: '爱客盈商品', content: '需要支付100元', fontColor: 'gray' },{ name: '爱客盈商品1', content: '需要支付999元', fontColor: 'red' }],
//   success: (r) => {
//     my.showToast({ content: r.barCode });
//     this.cashPaymentTrade(r.barCode);
//     // this.showToast(payStatus.message);
//     // this.updatePaymentListByTradeNo(trade.tradeNo);
//     // this.setData({
//     //     paymentHistory: updatePayment,
//     //     isPaying: false
//     //   });
//   }
// });
    
},

// 获取输入账号 
  usernameInput: function (e) {
    this.setData({
      username: e.detail.value
    })
  },
 
  // 获取输入密码 
  passwordInput: function (e) {
    this.setData({
      password: e.detail.value
    })
  },

  // 登录处理
  loginTap: function () {
    // var arg=('uid='+10001+'&zdcode='+2846)
    var that = this;
    if (that.data.username.length == 0 || that.data.password.length == 0) {
      my.showToast({
        content: '账号或密码不能为空',
        icon: 'none',
        duration: 2000
      })
    } else {
      my.request({
        url: 'https://api.aikeying.cn/pospapi/app/getMerchantKey.jhtml?', // 仅为示例，并非真实的接口地址
        data: {
          zdcode: that.data.password,
          uid:that.data.username,
        },
        success(res){
          if (res.data.status == 1) {
            that.loginhttp(that.data.password,that.data.username,res.data.info);
          } else {
            my.showToast({
              content: res.data.info
            })
          }
        }
      })
    }
  },

  // 登录处理
  // loginTap: function () {
  //   // var arg=('uid='+10001+'&zdcode='+2846)
  //   var that = this;
  //   if (that.data.username.length == 0 || that.data.password.length == 0) {
  //     my.showToast({
  //       content: '账号或密码不能为空',
  //       icon: 'none',
  //       duration: 2000
  //     })
  //   } else {
  //     var arg=('uid='+that.data.username+'&zdcode='+that.data.password);
  //     var sign=that.getSign(arg,'451b54dcaf814ae791df7a68a1161b55');
  //     my.request({
  //       url: 'https://zlyapi.boiin.com/app/qrLogin.jhtml?', // 仅为示例，并非真实的接口地址
  //       data: {
  //         zdcode: that.data.password,
  //         uid:that.data.username,
  //         sign:sign
  //       },
  //       success(res){
  //         var rstObj = JSON.parse(res.data); //字符串转为对象
  //         if (rstObj.status == 1) {
  //           my.setStorageSync({
  //             key: 'LoginStatus',
  //             data: {
  //               status: 1,
  //               userids: that.data.username,
  //               usercodes: that.data.password
  //             }
  //           });
  //           my.showToast({
  //             content: '登录成功'
  //           })
  //           my.redirectTo({
  //             url: '../homes/homes',
  //           });
  //         } else {
  //           my.showToast({
  //             content: rstObj.info
  //           })
  //         }
  //       }
  //     })
  //   }
  // },
  
  loginhttp(zdcode,uid,key){
    var that = this;
    var arg=('uid='+uid+'&zdcode='+zdcode);
    var sign=that.getSign(arg,key);
    return new Promise(() => {
      my.request({
        url: 'https://api.aikeying.cn/pospapi/app/qrLogin.jhtml?', // 仅为示例，并非真实的接口地址
        data: {
          zdcode: zdcode,
          uid:uid,
          sign:sign
        },
        success(res){
          var rstObj = JSON.parse(res.data); //字符串转为对象
          if (rstObj.status == 1) {
            my.setStorageSync({
              key: 'LoginStatus',
              data: {
                status: 1,
                userids: uid,
                usercodes: zdcode,
                Devekey:key,
              }
            });
            my.showToast({
              content: '登录成功'
            })
            my.redirectTo({
              url: '../homes/homes',
            });
          } else {
            my.showToast({
              content: rstObj.info
            })
          }
        }
      })
    });
    
  },
  // getMerchantKey(){
  //   my.request({
  //       url: 'https://zlyapi.boiin.com/app/getMerchantKey.jhtml?',
  //       data: {
  //         zdcode: that.data.password,
  //         uid:that.data.username,
  //       },
  //       success: (result) => {
  //         var rstObj = JSON.parse(result.data); //字符串转为对象
  //         if (rstObj.status==0) {
  //           my.showToast({ content: rstObj.info});
  //         } else {
  //           resolve(rstObj.info);
  //         }
  //       },
  //       fail: (err) => {
  //         reject({
  //           message: '系统异常',
  //           ...err
  //         });
  //       }
  //     });

  // },
  // 验签
  getSign(args, key){
    args=args.split('&');
    args=args.sort();
    var requestString = '';
    for ( var i = 0; i <args.length; i++){
      var str=args[i];
      var arr=str.split('=');
      if(arr[1]!=null&&arr[1]!=""){
      requestString=requestString + arr[0] + '=' + arr[1] + '&';
      }
    }
    requestString = requestString + 'key=' + key;
    var newSign=MD5s.hexMD5(requestString).toUpperCase();
    return newSign;
  }
});
