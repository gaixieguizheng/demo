App({
  onLaunch: function() {
        //初始化加载，先判断用户登录状态
        let res = my.getStorageSync({ key: 'LoginStatus' });
        if (res.data.status != 1) {
            my.redirectTo({
                url: '../index/index'
            })
        }
  
  },
  globalData:{
        g_isPlayingMusic:false,
        g_currentMusicPostId:null,
        doubanBase: "http://t.yushu.im",
  }
    
})